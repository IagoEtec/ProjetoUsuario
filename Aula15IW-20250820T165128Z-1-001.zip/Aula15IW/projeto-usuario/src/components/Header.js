function Header(props){
    return(
        <div>
        <header>
            <h1>Projeto aula 15</h1>
            <p>Perfil de usuario</p>
        </header>
        </div>
    )
}

export default Header