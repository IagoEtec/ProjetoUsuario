function Footer(props){
    return(
        <div>
            <footer>
            <p>2025 Ribeirão Pires ©Todos os direitos reservados.</p>
            </footer>
        </div>
    )
}

export default Footer