function Cartao(props) {
    return (
        <section>
            <img src="/perfil.jpg" alt="Foto de perfil" />
            <p>Nome: Lebron James</p>
            <p>Profissão: Jogador de basquete</p>
            <p>Integrante da equipe Lakers da NBA</p>
        </section>
    );
}

export default Cartao;